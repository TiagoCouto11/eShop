<?php 

session_start();

$usuario_padrao = "adriano";
$senha_padrao = "fatec123";


$usuario_digitado = $_POST["usuario"];
$senha_digitada = $_POST["senha"];                                              

$_SESSION['usuario'] = $usuario_digitado;

if ($usuario_padrao == $usuario_digitado){
    if ($senha_padrao == $senha_digitada){
        $_SESSION["usuario_logado"] = $usuario_digitado;
        header("location: index.php");

    }  else {
        header("Location: login.html?falhou=true");
    }

} else {
        header("Location: login.html?falhou=true");
}

?>