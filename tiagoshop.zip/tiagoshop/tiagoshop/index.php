<?php

session_start();

$_SESSION["usuario_logado"] = "";

if (!isset($_SESSION["usuario_logado"])){
     header("Location: login.html");
 }

if (isset($_GET["sair"])){
    unset($_SESSION["usuario_logado"]);
    header("Location: login.html");
}

//var_dump ($_SESSION);




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tiago Shop</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <!-- bootstrap links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- bootstrap links -->
    <!-- fonts links -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather&display=swap" rel="stylesheet">
    <!-- fonts links -->
</head>
<body>

 

    <!-- navbar -->
    <nav class="navbar navbar-expand-lg" id="navbar">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php" id="logo"><span id="span1"></span>Tiago <span>Shop</span></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span><img src="./imagens/menu.png" alt="" width="30px"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="produto.html">Produtos</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Categoria
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: rgb(11, 7, 255);">
                  <li><a class="dropdown-item" href="#">Celular</a></li>
                  <li><a class="dropdown-item" href="#">Camêra</a></li>
                  <li><a class="dropdown-item" href="#">Geladeira</a></li>
                  <li><a class="dropdown-item" href="#">Videogame</a></li>
                  <li><a class="dropdown-item" href="#">Smart Watch</a></li>
                  <li><a class="dropdown-item" href="#">Fones de Ouvido</a></li>
                  <li><a class="dropdown-item" href="#">Notebook</a></li>
                  <li><a class="dropdown-item" href="#">Monitor Gamer</a></li>
                  <li><a class="dropdown-item" href="#">PC Gamer</a></li>
                </ul>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="sobre.html">Sobre</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contato.html">Fale Conosco</a>
              </li>
              <li class="nav-item">
                
                <a class="nav-link" href="carrinho.html">
                <i class="bi bi-cart4">
                  
                   <div class="button">

                   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-cart4" viewBox="0 0 16 16">
                    <path d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z"/>
                  </svg></i>


                    </div>
              </li>
            </ul>
            <form class="d-flex" id="search">
              <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Search">
              <button class="btn btn-outline-success" type="submit">Buscar</button>
            </form>
          </div>
        </div>
      </nav>
    <!-- navbar -->
    






    
    <!-- Painel Home -->
    <section class="home">
    <div class="content">
      <h1> <span>Produtos Eletrônicos</span>
        <br>
        Com Até<span id="span2">50%</span> Off
      </h1>
      <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dicta, saepe.
        <br>Lorem ipsum dolor sit amet consectetur.
      </p>
      <div class="btn"><button>Compre Aqui</button></div>

    </div>
    <div class="img">
      <img src="./imagens/background.png" alt="">
    </div>
    </section>
    <!-- Painel Home -->








      <!-- Card de Produtos -->
      <div class="container" id="product-cards">
      <h1 class="text-center">PRODUTOS</h1>
      <div class="row" style="margin-top: 30px;">
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/p6.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Iphone 13 Pro</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$7000 <a href="carrinho.html?id_produto=1"><span><li class="fa-solid fa-cart-shopping"></li></span></a></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/a1.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Air Pods</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$1000 <a href="carrinho.html?id_produto=2"> <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/laptop2.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Notebook</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$2000 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/t1.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Ipad</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$3000 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
      </div>

      <div class="row" style="margin-top: 30px;">
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/w1.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Smart Watch</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$1500 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pcm1.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Monitor</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$600 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/phone1.png" alt="">
            <div class="card-body">
              <h3 class="text-center">iPhone X</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$3000 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/h1.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Fones de Ouvido</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$400 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Card de Produtos -->








    <!-- Outros Cards -->
    <div class="container" id="other-cards">
      <div class="row">
        <div class="col-md-6 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/c1.png" alt="">
            <div class="card-img-overlay">
              <h3>Melhor Notebook </h3>
              <h5>Última Coleção</h5>
              <p>Com Até 50% Off</p>
              <button id="shopnow">Comprar</button>
            </div>
          </div>
        </div>
        <div class="col-md-6 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/c2.png" alt="">
            <div class="card-img-overlay">
              <h3>Melhor Fone de Ouvido</h3>
              <h5>Última Coleção</h5>
              <p>Com Até 50% Off</p>
              <button id="shopnow">Comprar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Outros Cards -->
   






    







    <!-- Card Produtos 2 -->
    <div class="container" id="product-cards">

      <div class="row" style="margin-top: 30px;">
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr1.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Máquina de Lavar Roupas</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$4000 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr2.png" alt="">
            <div class="card-body">
              <h3 class="text-center">AC Portátil</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$2000 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr3.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Micro-Ondas</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$500 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr4.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Geladeira</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>$3000 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
      </div>

    <!-- Outros Cards -->
    <div class="container" id="other">
      <div class="row">
        <div class="col-md-4 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/c3.png" alt="">
            <div class="card-img-overlay">
              <h3>Eletrodomésticos</h3>
              <p>Última Coleção Com Até 50% Off</p>
            </div>
          </div>
        </div>
        <div class="col-md-4 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/c4.png" alt="">
            <div class="card-img-overlay">
              <h3>Jogos</h3>
              <p>Última Coleção Com Até 50% Off</p>
            </div>
          </div>
        </div>
        <div class="col-md-4 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/c5.png" alt="">
            <div class="card-img-overlay">
              <h3>Eletrônicos</h3>
              <p>Última Coleção Com Até 50% Off</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Outros Cards -->




      <div class="row" style="margin-top: 30px;">
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr5.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Ventilador de Mesa</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$250 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr6.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Geladeira 2 Portas</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>$15000 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr7.png" alt="">
            <div class="card-body">
              <h3 class="text-center">PC Gamer</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$5000 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr8.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Monitor </h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$400 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
      </div>



      <div class="row" style="margin-top: 30px;">
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr9.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Smart Watch</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$1500 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr10.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Power Bank</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$100 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr11.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Mouse GAMER</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$300 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <div class="card">
            <img src="./imagens/pr12.png" alt="">
            <div class="card-body">
              <h3 class="text-center">Controles</h3>
              <p class="text-center">Lorem ipsum dolor sit amet.</p>
              <div class="star text-center">
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
                <i class="fa-solid fa-star checked"></i>
              </div>
              <h2>R$200 <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- product cards -->









    <!-- offer -->
    <div class="container" id="offer">
      <div class="row">
        <div class="col-md-3 py-3 py-md-0">
          <i class="fa-solid fa-cart-shopping"></i>
          <h3>Frete Grátis</h3>
          <p>Em compras acima de R$1000</p>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <i class="fa-solid fa-rotate-left"></i>
          <h3>Devoluções Gratuitas</h3>
          <p>Dentro de até 30 Dias</p>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <i class="fa-solid fa-truck"></i>
          <h3>Entrega Rápida</h3>
          <p>Em todo o território nacional</p>
        </div>
        <div class="col-md-3 py-3 py-md-0">
          <i class="fa-solid fa-thumbs-up"></i>
          <h3>Grande Escolha</h3>
          <p>de Produtos</p>
        </div>
      </div>
    </div>
    <!-- offer -->






    
   <!-- newslater -->
   <div class="container" id="newslater">
      <h3 class="text-center">Inscreva-se em TiagoShop para receber as ofertas.</h3>
      <div class="input text-center">
        <input type="text" placeholder="Digite aqui seu E-mail...">
        <button id="subscribe">INSCREVER-SE</button>
      </div>
    </div>
    <!-- newslater -->






    <!-- footer -->
    <footer id="footer">
      <div class="footer-top">
        <div class="container">
          <div class="row">

            <div class="col-lg-3 col-md-6 footer-contato">
              <h3>Tiago Shop</h3>
              <p>
                Cuiabá <br>
                MT <br>
                Rua Aurélio Vieira <br>
              </p>
              <strong>Telefone:</strong> +55(27)3678-6700<br>
              <strong>Email:</strong> shophelp@gmail.com <br>
            </div>

            <div class="col-lg-3 col-md-6 footer-links">
              <h4>Links Úteis</h4>
             <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">Sobre Nós</a></li>
              <li><a href="#">Produtos</a></li>
              <li><a href="#">Termos de Serviço</a></li>
              <li><a href="#">Política de Privacidade</a></li>
             </ul>
            </div>



           

            <div class="col-lg-3 col-md-6 footer-links">
              <h4>Nossos Produtos</h4>

             <ul>
              <li><a href="#">Playstation 5</a></li>
              <li><a href="#">Computador</a></li>
              <li><a href="#">Notebook</a></li>
              <li><a href="#">Celular</a></li>
              <li><a href="#">PC GAMER</a></li>
             </ul>
            </div>

            <div class="col-lg-3 col-md-6 footer-links">
              <h4>Nossas Redes Sociais</h4>
              <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia, quibusdam.</p>

              <div class="socail-links mt-3">
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-skype"></i></a>
                <a href="#"><i class="fa-brands fa-linkedin"></i></a>
              </div>
            
            </div>

          </div>
        </div>
      </div>
      <hr>
      <div class="container py-4">
        <div class="copyright">
          &copy; Copyright <strong><span>Tiago Shop</span></strong>. Todos os Direitos Reservados
        </div>
        <div class="credits">
          Designed by <a href="#">Tiago Couto</a>
        </div>
      </div>
    </footer>
    <!-- footer -->







    <a href="#" class="arrow"><i><img src="./imagens/arrow.png" alt=""></i></a>













    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>